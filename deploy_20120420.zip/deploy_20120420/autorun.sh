#!/bin/sh
ln -s /mnt/sd/DCIM/122_TREK/bin/* /bin/
ln -s /mnt/sd/DCIM/122_TREK/usr/bin/* /usr/bin/
ln -s /mnt/sd/DCIM/122_TREK/usr/local /usr/local
ln -s /mnt/sd/DCIM/122_TREK/usr/lib /usr/lib
ln -s /mnt/sd/DCIM/122_TREK/usr/include /usr/include
ln -s /mnt/sd/DCIM/122_TREK/usr/libexec /usr/libexec
ln -s /mnt/sd/DCIM/122_TREK/sbin/* /sbin/
ln -s /mnt/sd/DCIM/122_TREK/lib/* /lib/
ln -s /mnt/sd/DCIM/122_TREK/etc/* /etc/
ln -s /mnt/sd/DCIM/122_TREK/www/* /www/
ln -s /mnt/sd/DCIM/122_TREK/www/cgi-bin/* /www/cgi-bin/

ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/awk
rm /bin/dd
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/dd
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/find
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/grep
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/hexdump
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/killall
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/less
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/passwd
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/sed
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/tar
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/telnetd
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/watch
ln -s /mnt/sd/DCIM/122_TREK/busybox /bin/whoami

rm /usr/sbin/ftpd
rm /usr/bin/tcpsvd
ln -s /mnt/sd/DCIM/122_TREK/busybox /usr/sbin/ftpd
ln -s /mnt/sd/DCIM/122_TREK/busybox /usr/bin/tcpsvd

killall httpd
sleep 1

httpd -h /www -c /etc/httpd.conf&
tcpsvd 0.0.0.0 21 ftpd -w /&
sleep 1

killall telnetd
sleep 1

mount -t devpts /dev/pts
/mnt/sd/DCIM/122_TREK/busybox telnetd -l /bin/sh &
sleep 1

dropbear -A -N root -C admin -U 0 -G 0
sleep 1
